﻿using System;
using System.IO.Ports;
using System.Windows.Forms;
using System.Net.Http;
using System.Threading.Tasks;
using System.Threading;

namespace _01BASIC
{
    public partial class winform : Form
    {

        private string apiUrl = "http://localhost:8080/arduino";
        private HttpClient httpClient = new HttpClient();

        public winform()
        {
            InitializeComponent();

            InitializeAsync();


        }

        private async void InitializeAsync()
        {
            try
            {
                var tmpResponse = await httpClient.GetAsync($"{apiUrl}/message/tmp");
                var lightResponse = await httpClient.GetAsync($"{apiUrl}/message/light");
                var soundResponse = await httpClient.GetAsync($"{apiUrl}/message/distance");
                if (tmpResponse.IsSuccessStatusCode)
                {
                    var tmpResult = await tmpResponse.Content.ReadAsStringAsync();
                    tmp.Invoke((MethodInvoker)delegate
                    {
                        tmp.Text = tmpResult;
                    });

                    var lightResult = await lightResponse.Content.ReadAsStringAsync();
                    light.Invoke((MethodInvoker)delegate
                    {
                        light.Text = tmpResult;
                    });

                    var soundResult = await soundResponse.Content.ReadAsStringAsync();
                    sound.Invoke((MethodInvoker)delegate
                    {
                        sound.Text = tmpResult;
                    });
                }
            }
            catch (Exception ex) { }
        }




        private async Task button1_Click(object sender, EventArgs e)
        {
            // LED 켜기 버튼 클릭 이벤트 처리
            try
            {
                await SendLedControl("1");
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO ON LED: " + ex.Message);
            }
        }

        private async Task button2_ClickAsync(object sender, EventArgs e)
        {
            // LED 끄기 버튼 클릭 이벤트 처리
            try
            {
                await SendLedControl("0");
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO OFF LED: " + ex.Message);
            }
        }
        private async Task SendLedControl(string value)
        {
            var ledctrl = await httpClient.GetAsync($"{apiUrl}/led/{value}");

            if (ledctrl.IsSuccessStatusCode)
            {
                var ledResponse = await httpClient.GetAsync($"{apiUrl}/message/led");
                var ledResult = await ledResponse.Content.ReadAsStringAsync();
                ledlog.Invoke((MethodInvoker)delegate
                {
                    ledlog.Text = ledResult;
                });
            }
            else
            {
                MessageBox.Show("LED Control Failed...");
            }
        }




    }
}
